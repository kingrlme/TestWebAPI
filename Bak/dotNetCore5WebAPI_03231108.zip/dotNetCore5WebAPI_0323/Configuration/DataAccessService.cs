﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Model.DataAccessLayer;
using Dapper;
using System.Text;

namespace dotNetCore5WebAPI_0323.Configuration
{
    public class DataAccessService
    {
        /// <summary>
        /// 連線字串
        /// </summary>
        private static readonly string _connectionStr = "Data Source=localhost;" +
                                                        "Database=EmmaDB;" +
                                                        "user id=emma;" +
                                                        "password=emma";

        /// <summary>
        /// 全域的資料庫連線字串
        /// </summary>
        public static string ConnectionStr { get { return _connectionStr; } }


        /// <summary>
        /// 查詢所有 UserData
        /// </summary>
        /// <returns></returns>
        public List<UserData> GetAllUsers()
        {
            List<UserData> users = null;

            string sqlCommand = @"
                    SELECT [UID]
                          ,[UserID]
                          ,[UserName]
                          ,[UserPhone]
                          ,[UserOrgID]
                          ,[UserAddrZipCode]
                          ,[UserAddr]
                          ,[CityID]
                          ,[TownID]
                          ,[User_status]
                    FROM [UserData]
                    WHERE 1=1 
                    ORDER BY [UID] 
                    ";
            using (var conn = new SqlConnection(ConnectionStr))
            {
                users = conn.Query<UserData>(sqlCommand).ToList();
            }
            return users;
        }

        /// <summary>
        /// 查詢 UserData
        /// </summary>
        /// <param name="UID">UserID</param>
        /// <returns></returns>
        public List<UserData> GetUserData(string UID)
        {
            List<UserData> users = null;

            string sqlCommand = @"
                    SELECT [UID]
                          ,[UserID]
                          ,[UserName]
                          ,[UserPhone]
                          ,[UserOrgID]
                          ,[UserAddrZipCode]
                          ,[UserAddr]
                          ,[CityID]
                          ,[TownID]
                          ,[User_status]
                    FROM [UserData]
                    WHERE 1=1 
                    ";

            using (var conn = new SqlConnection(ConnectionStr))
            {
                if (!UID.Equals(""))
                {
                    sqlCommand += " AND [UserData].UID=@UID";
                    DynamicParameters parameters = new();
                    parameters.Add("UID", UID, DbType.String, ParameterDirection.Input, 50);
                    users = conn.Query<UserData>(sqlCommand, parameters, commandType: CommandType.Text).ToList();
                    //接回Output值
                    //int outputResult = parameters.Get<int> ("@OutPut1");
                }
                else
                {
                    users = conn.Query<UserData>(sqlCommand).ToList();
                }
            }
            return users;

            

        }

        /// <summary>
        /// 更新 UserData
        /// </summary>
        /// <param name="UID">User UID</param>
        /// <param name="OneUser">Update Date</param>
        /// <returns>0:更新失敗;1:已更新;2.找不到該UID使用者資料</returns>
        public int UpdateUserData(string UID, List<UserData> NewUser)
        {
            int count = 0;
            string sqlCommand;
            try
            {
                using (var conn = new SqlConnection(ConnectionStr))
                {
                    // Check User is exist or not
                    sqlCommand = @"SELECT * FROM [UserData] WHERE [UserData].UID=@UID";
                    List<UserData> OneUser = null;
                    OneUser = conn.Query<UserData>(sqlCommand, new { UID }).ToList();
                    if (OneUser == null || OneUser.Count == 0)
                    {
                        count = 2;
                    }
                    else
                    {
                        sqlCommand = @"
                                UPDATE [UserData]
                                   SET [UserID] = @UserID
                                      ,[UserName] = @UserName
                                      ,[UserPhone] = @UserPhone
                                      ,[UserOrgID] = @UserOrgID
                                      ,[UserAddrZipCode] = @UserAddrZipCode
                                      ,[UserAddr] = @UserAddr
                                      ,[CityID] = @CityID
                                      ,[TownID] = @TownID
                                      ,[User_status] = @User_status
                                 WHERE 1=1
                                ";

                        if (!UID.Equals("") && NewUser != null)
                        {
                            sqlCommand += " AND [UserData].UID=@UID";
                            count = conn.Execute(sqlCommand, NewUser);
                        }
                    }
                        
                }
            }
            catch (Exception ex)
            {
                ex.StackTrace.ToString();
            }
            return count;

        }

        /// <summary>
        /// Delete UserData By UID
        /// </summary>
        /// <param name="UID">User UID</param>
        /// <returns>0:刪除失敗;1:刪除成功;2.找不到該UID使用者資料</returns>
        public int DeleteUserData(string UID)
        {
            int count = 0;
            string sqlCommand;
            try
            {
                using (var conn = new SqlConnection(ConnectionStr))
                {
                    // Check User is exist or not
                    sqlCommand = @"SELECT * FROM [UserData] WHERE [UserData].UID=@UID";
                    List<UserData> OneUser = null;
                    OneUser = conn.Query<UserData>(sqlCommand, new { UID }).ToList();
                    if (OneUser == null || OneUser.Count == 0)
                    {
                        count = 2;
                    }
                    else
                    {
                        sqlCommand = @"DELETE FROM [UserData] WHERE [UID] = @UID";
                        count = conn.Execute(sqlCommand, new { UID });
                    }
                }
            }
            catch (Exception ex)
            {
                ex.StackTrace.ToString();
            }
            return count;
        }

        /// <summary>
        /// 新增使用者資料
        /// </summary>
        /// <param name="NewUser"></param>
        /// <returns>0:新增失敗;1:新增成功;2.已存在相同UID之使用者</returns>
        public int InsertUserData(List<UserData> NewUser)
        {
            int count = 0;
            string sqlCommand;
            try
            {
                using (var conn = new SqlConnection(ConnectionStr))
                {
                    // Check User is exist or not
                    sqlCommand = @"SELECT * FROM [UserData] WHERE [UserData].UID=@UID";
                    List<UserData> OneUser = null;
                    OneUser = conn.Query<UserData>(sqlCommand, new { NewUser[0].UID }).ToList();
                    if (OneUser == null || OneUser.Count == 0)
                    {
                        sqlCommand = @"INSERT INTO [UserData]([UID],[UserID],
                                                   [UserName],[UserPhone],[UserOrgID],
                                                   [UserAddrZipCode],[UserAddr],[CityID],
                                                   [TownID],[User_status])
                                        VALUES
                                                   (@UID,@UserID
                                                   ,@UserName,@UserPhone,@UserOrgID
                                                   ,@UserAddrZipCode,@UserAddr,@CityID
                                                   ,@TownID,@User_status)";
                        //新增多筆參數
                        count = conn.Execute(sqlCommand, new
                        {
                            NewUser[0].UID,
                            NewUser[0].UserID,
                            NewUser[0].UserName,
                            NewUser[0].UserPhone,
                            NewUser[0].UserOrgID,
                            NewUser[0].UserAddrZipCode,
                            NewUser[0].UserAddr,
                            NewUser[0].CityID,
                            NewUser[0].TownID,
                            NewUser[0].User_status
                        });
                    }
                    else
                    {
                        count = 2;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.StackTrace.ToString();
            }
            return count;
        }



        #region DataTableToJSON(DataTable dt)；傳入DataTable；回傳String
        /// <summary>
        ///  串JSON
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public string DataTableToJSON(DataTable dt)
        {
            StringBuilder StrJSON = new();
            StrJSON.Append('[');

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i != 0)
                    StrJSON.Append(",{");
                else
                    StrJSON.Append('{');

                for (int l = 0; l < dt.Columns.Count; l++)
                {
                    if (l != 0)
                        StrJSON.Append(",\"");
                    else
                        StrJSON.Append("\"");

                    StrJSON.Append(dt.Columns[l].ColumnName);
                    StrJSON.Append("\":\"");
                    StrJSON.Append(dt.Rows[i][l].ToString());
                    StrJSON.Append("\"");

                }
                StrJSON.Append('}');
            }
            StrJSON.Append(']');

            return StrJSON.ToString();
        }
        #endregion

    }
}
