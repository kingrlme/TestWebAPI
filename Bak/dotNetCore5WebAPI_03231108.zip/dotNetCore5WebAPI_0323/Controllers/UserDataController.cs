﻿using dotNetCore5WebAPI_0323.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Model.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace dotNetCore5WebAPI_0323.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserDataController : ControllerBase
    {
        private readonly ILogger<UserDataController> _logger;
        public UserDataController(ILogger<UserDataController> logger)
        {
            _logger = logger;
        }

        // Emma Connect to SQL SERVER and get DataTables
        readonly DataAccessService _DataAccess = new();

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IEnumerable<UserData> GetAllUsers()
        {
            List<UserData> AllUsers = _DataAccess.GetAllUsers();
            return AllUsers.ToArray();
        }

        [HttpGet("{UID}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<UserData> GetOneUserByUID(string UID)
        {
            if (UID == null) return BadRequest();
            List<UserData> OneUser = _DataAccess.GetUserData(UID);
            if (OneUser == null || OneUser.Count == 0)
            {
                return NotFound();
            }
            return CreatedAtAction(nameof(GetOneUserByUID), new { id = OneUser[0].UID }, OneUser);
        }


        [HttpPost]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult CreateNewUser(List<UserData> NewUser)
        { 
            if (NewUser == null || NewUser.Count == 0)
            {
                return NotFound();
            }
            int InsertStatus = _DataAccess.InsertUserData(NewUser);
            switch (InsertStatus)
            {
                case 0:
                    {
                        return NotFound();  // 沒有新增資料
                    }
                case 1:
                    {
                        return NoContent(); // 已新增一筆進資料庫。
                    }
                case 2:
                    {
                        return NotFound();  //已存在相同 UID 之資料
                    }
                default:
                    {
                        return NotFound();
                    }
            }
        }

        // PUT 更新[HttpPut]
        [HttpPut("{UID}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult UpdateOneUser(string UID, List<UserData> OneUser)
        {
            if (UID == null || !UID.Equals(OneUser[0].UID) || OneUser == null)
            {
                return BadRequest();
            }
            int UpdateStatus = _DataAccess.UpdateUserData(UID, OneUser);
            switch (UpdateStatus)
            {
                case 0:
                    {
                        return NotFound();  // 沒有新增資料
                    }
                case 1:
                    {
                        return NoContent(); // 已新增一筆進資料庫。
                    }
                case 2:
                    {
                        return NotFound();  //已存在相同 UID 之資料
                    }
                default:
                    {
                        return NoContent();
                    }
            }
        }


        // DELETE 刪除[HttpDelete]
        [HttpDelete("{UID}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult DeleteOneUserByUID(string UID)
        {
            if (UID == null) return BadRequest();
            int DelteStatus = _DataAccess.DeleteUserData(UID);
            switch (DelteStatus)
            {
                case 0:
                    {
                        return NotFound();  //刪除失敗
                    }
                case 1:
                    {
                        return NoContent(); //刪除成功
                    }
                case 2:
                    {
                        return NotFound();  //找不到符合的使用者資料
                    }
                default:
                    {
                        return NotFound();
                    }
            }
        }
        




    }
}
