using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dotNetCore5WebAPI_0323
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            //List<Member> members = _DataAccess.GetAllMembers();
            //List<UserData> users = _DataAccess.GetUserData();
            //List<UserData> OneUser = _DataAccess.GetUserData();

            Configuration = configuration;


            //get appsettings.json key/value
            //var myKeyValue = Configuration["MyKey"];
            //var title = Configuration["Position:Title"];
            //var name = Configuration["Position:Name"];
        }

        public IConfiguration Configuration { get; }


        // 1. �w��Swagger
        // �bCartApi�M�ץk��[�޲zNuGet�M��]�A�w��Swagger�������M��G�G
        // Swashbuckle.AspNetCore.SwaggerGen , ���� 5.6.1
        // Swashbuckle.AspNetCore.SwaggerUI , ���� 5.6.1

        // 2.�bStartup.cs���U�P�ϥ�Swagger
        // 2.1.ConfigureServices ���A�ȵ��U
        // �ݨϥ�SwaggerGen ���USwagger ���\��A�å[�W�惡Api�M�ת��y�z�C
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // AddControllers �X�R��k�|���U MVC ����һݪ��A��
            services.AddControllers();
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Version = "v1",
                    Title = "Emma's First .net core Web API",
                    Description = "Use Swagger UI and RESTful API"
                });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                // 2.2. Configure �[�W Swagger��Middleware
                //      �bPipeline �[�W Swagger��Middleware�A
                //      ��bapp.UseRouting���e�A���w���� json endpoint�P�W�١C
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(options =>
                {
                    options.SwaggerEndpoint(
                            $"/swagger/v1/swagger.json",
                            "Emma V1");
                });
                /*
                 3. �ק�launchSettings.json
                    �qVS����{�����ѼƷ|�̷�launchSettings.json�A
                    �]�tURL�P��L�����ܼơC
                    �ӭ���w�]�bIIS Express��launchUrl�Oweatherforecast�A
                    �N���令swagger�A�o��VS�ҥ�IIS���]�w�|��swagger�G
                 */
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
