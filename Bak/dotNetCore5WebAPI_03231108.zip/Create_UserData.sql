USE [EmmaDB]
GO

/****** Object:  Table [dbo].[UserData]    Script Date: 2021/3/23 �W�� 11:07:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserData](
	[UID] [nvarchar](50) NOT NULL,
	[UserID] [nvarchar](50) NULL,
	[UserName] [nvarchar](50) NULL,
	[UserPhone] [nvarchar](50) NULL,
	[UserOrgID] [nvarchar](50) NULL,
	[UserAddrZipCode] [nvarchar](50) NULL,
	[UserAddr] [nvarchar](50) NULL,
	[CityID] [nvarchar](50) NULL,
	[TownID] [nvarchar](50) NULL,
	[User_status] [nvarchar](50) NULL,
 CONSTRAINT [PK_UserData] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


